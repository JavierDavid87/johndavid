const DB_NAME = "AcademicPortfolioDB";
const STORE = "files";
const PROFILE_KEY = "portfolio_profile";
const ABOUT_KEY = "portfolio_about";

const categories = [
  {id:"quiz", title:"Quiz", icon:"📝", desc:"Quiz results and assessments"},
  {id:"long-quiz", title:"Long Quiz", icon:"📚", desc:"Long quiz results"},
  {id:"midterms", title:"Midterms Exam", icon:"📊", desc:"Midterm examination results"},
  {id:"finals", title:"Finals Exam", icon:"🎓", desc:"Final examination results"},
  {id:"activity", title:"Activities", icon:"⚙️", desc:"Class and learning activities"},
  {id:"laboratory", title:"Laboratory", icon:"💻", desc:"Laboratory activities and outputs"},
  {id:"project", title:"Projects", icon:"🚀", desc:"Projects and major outputs"}
];

let db;
let currentView = "grid";

const $ = (s) => document.querySelector(s);
const $$ = (s) => document.querySelectorAll(s);

function showToast(message){
  const t = $("#toast");
  t.textContent = message;
  t.classList.add("show");
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(()=>t.classList.remove("show"), 2600);
}

function openDB(){
  return new Promise((resolve,reject)=>{
    const req = indexedDB.open(DB_NAME,1);
    req.onupgradeneeded = e => {
      const database = e.target.result;
      if(!database.objectStoreNames.contains(STORE)){
        database.createObjectStore(STORE,{keyPath:"id"});
      }
    };
    req.onsuccess = e => { db=e.target.result; resolve(db); };
    req.onerror = () => reject(req.error);
  });
}

function dbRequest(mode, action){
  return new Promise((resolve,reject)=>{
    const tx=db.transaction(STORE,mode);
    const store=tx.objectStore(STORE);
    const req=action(store);
    req.onsuccess=()=>resolve(req.result);
    req.onerror=()=>reject(req.error);
  });
}

const getAllFiles=()=>dbRequest("readonly",s=>s.getAll());
const addFile=file=>dbRequest("readwrite",s=>s.put(file));
const removeFile=id=>dbRequest("readwrite",s=>s.delete(id));

function escapeHTML(value){
  return String(value).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));
}

function fileIcon(name){
  const ext=(name.split(".").pop()||"").toLowerCase();
  if(["pdf"].includes(ext)) return "📕";
  if(["doc","docx"].includes(ext)) return "📘";
  if(["xls","xlsx","csv"].includes(ext)) return "📗";
  if(["ppt","pptx"].includes(ext)) return "📙";
  if(["zip","rar","7z"].includes(ext)) return "🗜️";
  if(["txt","md"].includes(ext)) return "📄";
  return "📎";
}

function formatBytes(bytes){
  if(bytes < 1024) return `${bytes} B`;
  if(bytes < 1024**2) return `${(bytes/1024).toFixed(1)} KB`;
  if(bytes < 1024**3) return `${(bytes/1024**2).toFixed(1)} MB`;
  return `${(bytes/1024**3).toFixed(1)} GB`;
}

async function renderCategories(){
  const all=await getAllFiles();
  const search=$("#recordSearch").value.trim().toLowerCase();
  $("#fileCount").textContent=all.length;

  $("#categoryGrid").innerHTML=categories.map(cat=>{
    const files=all.filter(f=>f.category===cat.id && (!search || f.name.toLowerCase().includes(search)));
    return `
      <article class="category-card ${currentView==="list"?"list-mode":""}">
        <div class="category-head">
          <div class="category-title">
            <div class="category-icon">${cat.icon}</div>
            <div><h3>${cat.title}</h3><small>${cat.desc}</small></div>
          </div>
          <span class="count-badge">${files.length} file${files.length===1?"":"s"}</span>
        </div>
        <label class="upload-zone">
          <strong>＋ Upload files</strong>
          <span>Images, PDF, Word, PowerPoint, Excel and other files</span>
          <input type="file" multiple data-category="${cat.id}">
        </label>
        <div class="file-list">
          ${files.length ? files.map(fileCard).join("") : `<div style="grid-column:1/-1;color:#61748e;font-size:11px;padding:10px 2px">No files uploaded yet.</div>`}
        </div>
      </article>
    `;
  }).join("");

  $$(".upload-zone input").forEach(input=>{
    input.addEventListener("change", e=>handleUpload(e.target.files,e.target.dataset.category));
  });
  $$(".file-view").forEach(btn=>btn.addEventListener("click",()=>previewFile(btn.dataset.id)));
  $$(".file-download").forEach(btn=>btn.addEventListener("click",()=>downloadFile(btn.dataset.id)));
  $$(".file-delete").forEach(btn=>btn.addEventListener("click",()=>deleteStoredFile(btn.dataset.id)));
}

function fileCard(file){
  const isImage=file.type.startsWith("image/");
  return `
    <div class="file-item">
      ${isImage
        ? `<img class="file-thumb" src="${URL.createObjectURL(file.blob)}" alt="${escapeHTML(file.name)}">`
        : `<div class="file-generic">${fileIcon(file.name)}</div>`}
      <div class="file-meta" title="${escapeHTML(file.name)}">${escapeHTML(file.name)}</div>
      <div class="file-actions">
        <button class="icon-btn file-view" data-id="${file.id}" title="View">👁</button>
        <button class="icon-btn file-download" data-id="${file.id}" title="Download">↓</button>
        <button class="icon-btn delete file-delete" data-id="${file.id}" title="Delete">×</button>
      </div>
    </div>
  `;
}

async function handleUpload(fileList,category){
  if(!fileList.length) return;
  const files=[...fileList];
  for(const file of files){
    await addFile({
      id: crypto.randomUUID(),
      category,
      name:file.name,
      type:file.type || "application/octet-stream",
      size:file.size,
      createdAt:new Date().toISOString(),
      blob:file
    });
  }
  showToast(`${files.length} file${files.length>1?"s":""} uploaded to ${categories.find(c=>c.id===category).title}.`);
  await renderCategories();
}

async function previewFile(id){
  const file=(await getAllFiles()).find(f=>f.id===id);
  if(!file) return;
  const url=URL.createObjectURL(file.blob);
  let content="";
  if(file.type.startsWith("image/")){
    content=`<h3>${escapeHTML(file.name)}</h3><img class="preview-image" src="${url}" alt="${escapeHTML(file.name)}"><a class="btn btn-primary preview-download" href="${url}" download="${escapeHTML(file.name)}">Download File</a>`;
  } else if(file.type==="application/pdf"){
    content=`<h3>${escapeHTML(file.name)}</h3><iframe class="preview-frame" src="${url}"></iframe><a class="btn btn-primary preview-download" href="${url}" download="${escapeHTML(file.name)}">Download PDF</a>`;
  } else {
    content=`<div style="text-align:center;padding:50px 10px"><div style="font-size:55px">${fileIcon(file.name)}</div><h3 style="margin:15px 0 6px">${escapeHTML(file.name)}</h3><p style="color:#91a4bc;font-size:12px">${formatBytes(file.size)}</p><a class="btn btn-primary preview-download" href="${url}" download="${escapeHTML(file.name)}">Download File</a></div>`;
  }
  $("#previewContent").innerHTML=content;
  $("#previewModal").classList.add("open");
  $("#previewModal").setAttribute("aria-hidden","false");
}

async function downloadFile(id){
  const file=(await getAllFiles()).find(f=>f.id===id);
  if(!file) return;
  const url=URL.createObjectURL(file.blob);
  const a=document.createElement("a"); a.href=url; a.download=file.name; a.click();
  setTimeout(()=>URL.revokeObjectURL(url),1000);
}

async function deleteStoredFile(id){
  if(!confirm("Delete this uploaded file?")) return;
  await removeFile(id);
  showToast("File deleted.");
  renderCategories();
}

function closeModal(id){
  $(id).classList.remove("open");
  $(id).setAttribute("aria-hidden","true");
  $("#previewContent").innerHTML="";
}

function loadAbout(){
  const saved=localStorage.getItem(ABOUT_KEY);
  if(saved) $("#aboutText").textContent=saved;
}
function saveAbout(){
  const text=$("#aboutEditor").value.trim();
  if(!text) return;
  localStorage.setItem(ABOUT_KEY,text);
  $("#aboutText").textContent=text;
  $("#aboutModal").classList.remove("open");
  showToast("About Me updated.");
}

function loadProfile(){
  const saved=localStorage.getItem(PROFILE_KEY);
  if(saved) $("#profileImage").src=saved;
}

$("#profileUpload").addEventListener("change",e=>{
  const file=e.target.files[0];
  if(!file) return;
  if(!file.type.startsWith("image/")) return showToast("Please choose an image.");
  const reader=new FileReader();
  reader.onload=()=>{localStorage.setItem(PROFILE_KEY,reader.result);$("#profileImage").src=reader.result;showToast("Profile photo saved.");};
  reader.readAsDataURL(file);
});

$("#editAboutBtn").addEventListener("click",()=>{
  $("#aboutEditor").value=$("#aboutText").textContent;
  $("#aboutModal").classList.add("open");
});
$("#saveAboutBtn").addEventListener("click",saveAbout);
$$("[data-close-modal]").forEach(x=>x.addEventListener("click",()=>closeModal("#previewModal")));
$$("[data-close-about]").forEach(x=>x.addEventListener("click",()=>closeModal("#aboutModal")));

$("#recordSearch").addEventListener("input",renderCategories);
$("#gridViewBtn").addEventListener("click",()=>{currentView="grid";$("#gridViewBtn").classList.add("active");$("#listViewBtn").classList.remove("active");renderCategories()});
$("#listViewBtn").addEventListener("click",()=>{currentView="list";$("#listViewBtn").classList.add("active");$("#gridViewBtn").classList.remove("active");renderCategories()});

$("#exportBtn").addEventListener("click",async()=>{
  const files=await getAllFiles();
  const payload={
    version:1,
    about:localStorage.getItem(ABOUT_KEY)||$("#aboutText").textContent,
    profile:localStorage.getItem(PROFILE_KEY)||null,
    files:await Promise.all(files.map(async f=>({
      id:f.id,category:f.category,name:f.name,type:f.type,size:f.size,createdAt:f.createdAt,
      data:await blobToDataURL(f.blob)
    })))
  };
  const blob=new Blob([JSON.stringify(payload)],{type:"application/json"});
  const url=URL.createObjectURL(blob);const a=document.createElement("a");
  a.href=url;a.download="academic-portfolio-backup.json";a.click();
  setTimeout(()=>URL.revokeObjectURL(url),1000);
  showToast("Backup exported.");
});

function blobToDataURL(blob){
  return new Promise((resolve,reject)=>{
    const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=reject;r.readAsDataURL(blob);
  });
}
function dataURLToBlob(dataURL){
  const [meta,data]=dataURL.split(",");
  const mime=(meta.match(/:(.*?);/)||[])[1]||"application/octet-stream";
  const bin=atob(data);const arr=new Uint8Array(bin.length);
  for(let i=0;i<bin.length;i++) arr[i]=bin.charCodeAt(i);
  return new Blob([arr],{type:mime});
}

$("#importInput").addEventListener("change",async e=>{
  const file=e.target.files[0];if(!file)return;
  try{
    const payload=JSON.parse(await file.text());
    if(payload.about) localStorage.setItem(ABOUT_KEY,payload.about);
    if(payload.profile) localStorage.setItem(PROFILE_KEY,payload.profile);
    if(Array.isArray(payload.files)){
      for(const f of payload.files){
        await addFile({...f,blob:dataURLToBlob(f.data)});
      }
    }
    loadAbout();loadProfile();await renderCategories();
    showToast("Backup imported successfully.");
  }catch(err){console.error(err);showToast("Could not import that backup.");}
  e.target.value="";
});

$("#menuToggle").addEventListener("click",()=>$("#mainNav").classList.toggle("open"));
$$(".nav-link").forEach(link=>link.addEventListener("click",()=>$("#mainNav").classList.remove("open")));

const observer=new IntersectionObserver(entries=>{
  entries.forEach(entry=>{if(entry.isIntersecting) entry.target.classList.add("visible")});
},{threshold:.12});
function observeReveals(){$$(".reveal").forEach(el=>observer.observe(el));}

$("#year").textContent=new Date().getFullYear();

(async function init(){
  try{
    await openDB();loadAbout();loadProfile();await renderCategories();observeReveals();
  }catch(err){
    console.error(err);
    showToast("Your browser does not support local portfolio storage.");
  }
})();
