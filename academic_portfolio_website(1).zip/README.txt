# Academic Portfolio Website

## Files
- `index.html` — website structure
- `style.css` — professional responsive design, effects and animations
- `script.js` — uploads, previews, downloads, IndexedDB storage, profile photo, About Me editing, backup/import
- `profile.png` — the profile photo supplied for the Home section

## How to use
1. Keep all four files in the same folder.
2. Open `index.html` in Chrome, Edge, Firefox, or Safari.
3. Go to **Academic Records**.
4. Choose a category and upload multiple images/documents.
5. Click an uploaded image/document to preview it, or use the download button.
6. Change the Home profile photo using the small pencil button.
7. Edit **About Me** from the About section.

## Important: viewing on another device
The current version stores uploaded files in the browser's IndexedDB. That means the files persist on the same browser/device, but they are NOT automatically uploaded to the internet.

For a teacher to see the same uploaded records from another device, use one of these options:
- Export Backup on your current device, then Import Backup on the teacher's/device's browser.
- For true automatic cross-device sharing, connect the upload system to a cloud backend such as Firebase Storage + Firestore or Supabase Storage + Database. The front-end structure is already organized by category for that upgrade.

## GitHub Pages
This project can be hosted as a static website on GitHub Pages. The HTML/CSS/JS itself is compatible with static hosting. Remember that browser-stored uploads remain local to each browser unless cloud storage is added.

## Categories included
Quiz, Long Quiz, Midterms Exam, Finals Exam, Activities, Laboratory, Projects.
